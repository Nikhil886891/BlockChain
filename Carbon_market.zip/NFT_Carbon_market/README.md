# Carbon-Credit-Marketplace
Project-BTA

hi everyone this is  marketplace to buy or sell carbon credit NFT 
we can also create auction and bid for the NFT's

# how to run
configure the .env file and add your account private key if you want to become owner of market place
 otherwise just move to the directory and run 'npm start' to run
 
